package ar.edu.huergo.swapify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwapifyApplicationTests {

	@Test
	void contextLoads() {
	}

}
