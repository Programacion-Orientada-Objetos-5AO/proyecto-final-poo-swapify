package ar.edu.huergo.swapify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwapifyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwapifyApplication.class, args);
	}

}